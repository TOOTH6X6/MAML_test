package com.example.mamltheme

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Packs a MAML lockscreen manifest into a Xiaomi .mtz theme (zip of component zips). */
object MtzBuilder {

    fun build(out: File, title: String, lockscreenManifest: String) {
        // Component "lockscreen" is itself a zip containing advance/manifest.xml
        val lockscreen = zip(mapOf("advance/manifest.xml" to lockscreenManifest.toByteArray(Charsets.UTF_8)))
        ZipOutputStream(FileOutputStream(out)).use { z ->
            z.putStored("description.xml", description(title).toByteArray(Charsets.UTF_8))
            z.putStored("lockscreen", lockscreen)
        }
    }

    private fun zip(files: Map<String, ByteArray>): ByteArray {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z -> files.forEach { (n, d) -> z.putStored(n, d) } }
        return bos.toByteArray()
    }

    private fun ZipOutputStream.putStored(name: String, data: ByteArray) {
        val e = ZipEntry(name)
        e.method = ZipEntry.STORED
        e.size = data.size.toLong()
        e.compressedSize = e.size
        e.crc = CRC32().also { it.update(data) }.value
        putNextEntry(e)
        write(data)
        closeEntry()
    }

    private fun description(title: String) = """<?xml version="1.0" encoding="utf-8"?>
<theme>
    <title>$title</title>
    <designer>MamlThemeApplier</designer>
    <author>MamlThemeApplier</author>
    <version>1.0</version>
    <uiVersion>1</uiVersion>
</theme>
"""

    /** Sample based on Xiaomi's MAML docs: time, date, swipe-up-to-unlock. */
    val SAMPLE_LOCKSCREEN = """<?xml version="1.0" encoding="utf-8"?>
<Lockscreen version="2" frameRate="30" screenWidth="1080" useVariableUpdater="DateTime.Minute">
    <Wallpaper />
    <DateTime x="540" y="400" align="center" alignV="center" size="200" color="#ffffff" formatExp="ifelse(#time_format,'HH:mm','h:mm')" fontFamily="mitype-light" />
    <DateTime x="540" y="560" align="center" alignV="center" size="45" color="#ffffff" format="MM/dd  EEEE" />
    <Text x="#screen_width/2" y="#screen_height-100-#unlockMove" align="center" alignV="center" color="#ffffff" size="42" text="Swipe up to unlock" />
    <Group name="Unlock">
        <Var name="unlockMove" expression="ifelse(#unlockDown==1,max(#touch_begin_y-#touch_y,0),max(#touch_begin_y-#touch_y,0) { 300,max(#touch_begin_y-#touch_y,0)*(1-#unlockBack),0)" />
        <Var name="unlockBack">
            <VariableAnimation initPause="true" loop="false">
                <Item value="0" time="0" easeType="BounceEaseOut" />
                <Item value="1" time="300" />
            </VariableAnimation>
        </Var>
        <Button w="#screen_width" h="#screen_height">
            <Triggers>
                <Trigger action="down">
                    <VariableCommand name="unlockDown" expression="1" />
                </Trigger>
                <Trigger action="up,cancel">
                    <VariableCommand name="unlockDown" expression="0" />
                    <Command target="unlockBack.animation" value="play" />
                    <ExternCommand command="unlock" condition="max(#touch_begin_y-#touch_y,0) }= 300" />
                </Trigger>
            </Triggers>
        </Button>
    </Group>
</Lockscreen>
"""
}
