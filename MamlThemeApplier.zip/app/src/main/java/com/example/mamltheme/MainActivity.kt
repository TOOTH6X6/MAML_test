package com.example.mamltheme

import android.Manifest
import android.content.ComponentName
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.xml.sax.InputSource
import java.io.File
import java.io.StringReader
import javax.xml.parsers.DocumentBuilderFactory

class MainActivity : AppCompatActivity() {

    private val tm = "com.android.thememanager"
    private val applyActivity = "com.android.thememanager/com.android.thememanager.ApplyThemeForScreenshot"
    private lateinit var editor: EditText
    private lateinit var logView: TextView

    private val pickMtz = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val f = File(themesDir(), "picked.mtz")
            contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            applyMtz(f)
        }
    }

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        editor = findViewById(R.id.editor)
        logView = findViewById(R.id.log)
        editor.setText(MtzBuilder.SAMPLE_LOCKSCREEN)

        findViewById<Button>(R.id.btn_build).setOnClickListener { buildAndApply() }
        findViewById<Button>(R.id.btn_pick).setOnClickListener { pickMtz.launch(arrayOf("*/*")) }
        findViewById<Button>(R.id.btn_open).setOnClickListener { openThemeManager() }
    }

    private fun log(msg: String) {
        logView.append(msg + "\n")
    }

    private fun themesDir(): File = File(cacheDir, "themes").apply { mkdirs() }

    private fun buildAndApply() {
        val xml = editor.text.toString()
        try {
            DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(InputSource(StringReader(xml)))
        } catch (e: Exception) {
            log("XML ผิดพลาด: ${e.message}")
            return
        }
        val out = File(themesDir(), "maml_theme.mtz")
        try {
            MtzBuilder.build(out, "MAML Theme", xml)
        } catch (e: Exception) {
            log("สร้าง .mtz ไม่สำเร็จ: ${e.message}")
            return
        }
        applyMtz(out)
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    private fun tryStart(i: Intent, name: String): Boolean = try {
        startActivity(i)
        log("OK: $name")
        true
    } catch (e: Exception) {
        log("FAIL: $name (${e.javaClass.simpleName}: ${e.message})")
        false
    }

    private fun openThemeManager() {
        val i = Intent(Intent.ACTION_MAIN).apply {
            component = ComponentName(tm, "$tm.ThemeResourceTabActivity")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (!tryStart(i, "Theme Manager")) {
            packageManager.getLaunchIntentForPackage(tm)?.let { tryStart(it, "Theme Manager (launcher)") }
        }
    }

    /**
     * Theme Manager is a system app, so it reads the .mtz by real path.
     * The file therefore must live in shared storage (not in our private cache).
     * We save it to Download/MamlThemeApplier via MediaStore (no special permission on Android 10+).
     */
    private fun publishToDownloads(src: File, name: String): String? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MamlThemeApplier")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
                contentResolver.openOutputStream(uri)?.use { o -> src.inputStream().use { it.copyTo(o) } }
                contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val p = c.getString(0)
                        if (!p.isNullOrEmpty()) return p
                    }
                }
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "MamlThemeApplier/$name").absolutePath
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "MamlThemeApplier")
                dir.mkdirs()
                val dst = File(dir, name)
                src.copyTo(dst, overwrite = true)
                dst.absolutePath
            }
        } catch (e: Exception) {
            log("บันทึกไฟล์ไม่สำเร็จ: ${e.message}")
            null
        }
    }

    private fun applyMtz(f: File) {
        log("ไฟล์ ${f.name} (${f.length()} bytes)")
        if (!isInstalled(tm)) {
            log("ไม่พบ Theme Manager - เครื่องนี้ไม่ใช่ Xiaomi/HyperOS หรือถูกถอนออก")
            return
        }
        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
            log("ขอสิทธิ์จัดเก็บไฟล์ - อนุญาตแล้วกดปุ่มอีกครั้ง")
            return
        }

        val path = publishToDownloads(f, "maml_${System.currentTimeMillis()}.mtz")
        if (path != null) {
            log("บันทึกที่ $path")
            val i = Intent().apply {
                component = ComponentName.unflattenFromString(applyActivity)
                putExtra("theme_file_path", path)
                putExtra("api_called_from", tm)
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            if (tryStart(i, "ApplyThemeForScreenshot")) return
        }

        // สำรอง: ให้ Theme Manager เปิดไฟล์ผ่าน content uri
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/miui-mtz")
            setPackage(tm)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (tryStart(view, "VIEW -> Theme Manager")) return

        log("ใช้ไม่ได้ทั้งสองวิธี - เปิด Theme Manager แทน")
        openThemeManager()
    }
}
