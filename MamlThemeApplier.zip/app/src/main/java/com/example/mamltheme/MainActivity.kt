package com.example.mamltheme

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.xml.sax.InputSource
import java.io.File
import java.io.StringReader
import javax.xml.parsers.DocumentBuilderFactory

class MainActivity : AppCompatActivity() {

    private val tm = "com.android.thememanager"
    private lateinit var editor: EditText
    private lateinit var logView: TextView

    private val pickMtz = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val f = File(themesDir(), "picked.mtz")
            contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            applyMtz(f)
        }
    }

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        editor = findViewById(R.id.editor)
        logView = findViewById(R.id.log)
        editor.setText(MtzBuilder.SAMPLE_LOCKSCREEN)

        findViewById<Button>(R.id.btn_build).setOnClickListener { buildAndApply() }
        findViewById<Button>(R.id.btn_pick).setOnClickListener { pickMtz.launch(arrayOf("*/*")) }
        findViewById<Button>(R.id.btn_perm).setOnClickListener { requestFileAccess() }
        findViewById<Button>(R.id.btn_open).setOnClickListener { openThemeManager() }
    }

    private fun log(msg: String) {
        logView.append(msg + "\n")
    }

    private fun themesDir(): File = File(cacheDir, "themes").apply { mkdirs() }

    private fun buildAndApply() {
        val xml = editor.text.toString()
        try {
            DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(InputSource(StringReader(xml)))
        } catch (e: Exception) {
            log("XML ผิดพลาด: ${e.message}")
            return
        }
        val out = File(themesDir(), "maml_theme.mtz")
        try {
            MtzBuilder.build(out, "MAML Theme", xml)
        } catch (e: Exception) {
            log("สร้าง .mtz ไม่สำเร็จ: ${e.message}")
            return
        }
        applyMtz(out)
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    private fun hasFileAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestFileAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            val i = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            tryStart(i, "ตั้งค่าสิทธิ์ไฟล์")
        } else {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
    }

    private fun tryStart(i: Intent, name: String): Boolean = try {
        startActivity(i)
        log("OK: $name")
        true
    } catch (e: Exception) {
        log("FAIL: $name (${e.javaClass.simpleName})")
        false
    }

    private fun openThemeManager() {
        val i = Intent(Intent.ACTION_MAIN).apply {
            component = ComponentName(tm, "$tm.ThemeResourceTabActivity")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (!tryStart(i, "Theme Manager")) {
            packageManager.getLaunchIntentForPackage(tm)?.let { tryStart(it, "Theme Manager (launcher)") }
        }
    }

    private fun applyMtz(f: File) {
        log("ไฟล์ ${f.name} (${f.length()} bytes)")
        if (!isInstalled(tm)) {
            log("ไม่พบ Theme Manager - เครื่องนี้ไม่ใช่ Xiaomi/HyperOS หรือถูกถอนออก")
            return
        }

        // วิธี 1: คัดลอกไป /MIUI/theme แล้วสั่ง Theme Manager ให้ apply
        var publicPath: String? = null
        if (hasFileAccess()) {
            try {
                val dir = File(Environment.getExternalStorageDirectory(), "MIUI/theme").apply { mkdirs() }
                val dst = File(dir, f.name)
                f.copyTo(dst, overwrite = true)
                publicPath = dst.absolutePath
                log("คัดลอกไปที่ $publicPath")
            } catch (e: Exception) {
                log("คัดลอกไม่สำเร็จ: ${e.message}")
            }
        } else {
            log("ยังไม่ได้ให้สิทธิ์ไฟล์ทั้งหมด - ข้ามวิธี 1")
        }
        if (publicPath != null) {
            val i = Intent().apply {
                component = ComponentName(tm, "$tm.ApplyThemeForScreenshot")
                putExtra("theme_file_path", publicPath)
                putExtra("api_called_from", "test")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (tryStart(i, "ApplyThemeForScreenshot")) return
        }

        // วิธี 2: ส่งไฟล์ให้ Theme Manager เปิดตรงๆ
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/octet-stream")
            setPackage(tm)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (tryStart(view, "VIEW -> Theme Manager")) return

        // วิธี 3: เปิด Theme Manager ให้เลือกธีมเอง
        log("ใช้ 2 วิธีแรกไม่ได้ - เปิด Theme Manager แทน (ธีมอยู่ใน MIUI/theme ถ้าคัดลอกสำเร็จ)")
        openThemeManager()
    }
}
